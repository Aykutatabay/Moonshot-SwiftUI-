//
//  Astronaut.swift
//  Moonshot(SwiftUI)
//
//  Created by Aykut ATABAY on 16.10.2022.
//

import Foundation


struct Astronaut: Codable, Identifiable {
    let id: String
    let name: String
    let description: String
}
