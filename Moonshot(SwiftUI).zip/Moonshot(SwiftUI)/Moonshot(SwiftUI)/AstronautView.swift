//
//  AstronautView.swift
//  Moonshot(SwiftUI)
//
//  Created by Aykut ATABAY on 16.10.2022.
//

import SwiftUI

struct AstronautView: View {
    
    let astronaut: Astronaut
    var body: some View {
        NavigationView {
            ScrollView {
                Image("\(astronaut.id)")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 300, height: 300, alignment: .center)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .padding()
                Text(astronaut.description)
                    .padding()
                    
            }
            .frame(maxWidth: .infinity)
            .navigationTitle(astronaut.name)
            .navigationBarTitleDisplayMode(.inline)
            .background(.black.opacity(0.7))
            
        }
    }
}

struct AstronautView_Previews: PreviewProvider {
    static let astronaut: [String: Astronaut] = Bundle.main.decode("astronauts.json")
    static var previews: some View {
        AstronautView(astronaut: astronaut["gordon"]! )
    }
}
