//
//  MissionView.swift
//  Moonshot(SwiftUI)
//
//  Created by Aykut ATABAY on 16.10.2022.
//

import SwiftUI

struct MissionView: View {
    struct CrewMember {
        let astronaut: Astronaut
        let role: String
    }
    let mission: Mission
    let crew: [CrewMember]
    
    var body: some View {
            ScrollView {
                Text("Apollo \(mission.id)")
                    .font(.largeTitle)
                    .bold()
                    Image("apollo\(mission.id)")
                        .resizable()
                        .scaledToFit()
                        .shadow(color: .black, radius: 20, x: 20, y: 20)
                        .frame(width: 200, height: 200)
                        .padding()
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("Mission Highligts")
                        .font(.title)
                        .bold()
                        .padding()

                    Text(mission.description)
                        .padding()
                }

                ScrollView (.horizontal) {
                    HStack {
                        ForEach(crew, id: \.role) { astronaut in
                            NavigationLink(destination: AstronautView(astronaut: astronaut.astronaut), label: {
                                Image("\(astronaut.astronaut.id)")
                                .clipShape(RoundedRectangle(cornerRadius: 15))
                            VStack(alignment: .leading) {
                                Text("\(astronaut.astronaut.name)")
                                    .font(.headline)
                                Text("\(astronaut.role)")
                                    .foregroundColor(.white)
                            }
                            })
                            
                        }
                    }
                }
                .padding()
            }
            .background(.gray)
    }
    init(mission: Mission, astonauts: [String: Astronaut]) {
        self.mission = mission
        self.crew = mission.crew.map { member in
            if let astronaut = astonauts[member.name] {
                return CrewMember(astronaut: astronaut, role: member.role)
            } else {
                fatalError("missing \(member.name)")
            }            
        }
    }
}

struct MissionView_Previews: PreviewProvider {
    static let astronaut: [String: Astronaut] = Bundle.main.decode("astronauts.json")
    static let missions: [Mission] = Bundle.main.decode("missions.json")
    static var previews: some View {
        MissionView(mission: missions[1], astonauts: astronaut)
    }
}
