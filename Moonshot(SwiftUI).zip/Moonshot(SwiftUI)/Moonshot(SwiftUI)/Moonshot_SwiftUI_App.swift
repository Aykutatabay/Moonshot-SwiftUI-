//
//  Moonshot_SwiftUI_App.swift
//  Moonshot(SwiftUI)
//
//  Created by Aykut ATABAY on 16.10.2022.
//

import SwiftUI

@main
struct Moonshot_SwiftUI_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
