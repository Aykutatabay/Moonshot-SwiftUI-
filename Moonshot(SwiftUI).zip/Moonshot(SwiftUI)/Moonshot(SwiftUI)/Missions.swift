//
//  Missions.swift
//  Moonshot(SwiftUI)
//
//  Created by Aykut ATABAY on 16.10.2022.
//

import Foundation

struct Mission: Codable, Identifiable {    
    struct CrewRole: Codable {
        let name: String
        let role: String
    }
    let id: Int
    let crew: [CrewRole]
    let launchDate: Date?
    let description: String
    
    var formattedLaunchDate: String {
        launchDate?.formatted(date: .abbreviated, time: .omitted) ?? "N/A"
    }
}


