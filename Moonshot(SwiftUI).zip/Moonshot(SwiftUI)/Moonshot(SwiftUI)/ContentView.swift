//
//  ContentView.swift
//  Moonshot(SwiftUI)
//
//  Created by Aykut ATABAY on 16.10.2022.
//

import SwiftUI

struct ContentView: View {
    
    let astronaut: [String: Astronaut] = Bundle.main.decode("astronauts.json")
    let missions: [Mission] = Bundle.main.decode("missions.json")
    
    let columns = [
        GridItem(.adaptive(minimum: 170), spacing: 0)
    ]
    var body: some View {
        NavigationView {
            ScrollView {
                LazyVGrid(columns: columns){
                    ForEach(missions) { x in
                        NavigationLink(destination: MissionView(mission: x, astonauts: astronaut), label: {
                            VStack(spacing: 0){
                                Image("apollo\(x.id)")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 150, height: 140)
                                    .padding()
                                    .background(.black)
                                VStack {
                                    Text("Apollo\(x.id)")
                                        .foregroundColor(.black)
                                    Text(x.formattedLaunchDate)
                                        .foregroundColor(.gray)
                                        
                                }
                                .frame(width: 150, height: 20)
                                .padding()
                                .background(.black.opacity(0.4))
                                
                            }
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .overlay(RoundedRectangle(cornerRadius: 10)
                                .stroke(.black)
                            )
                            .padding()
                        })
                    }
                
                }
                
            }
            .navigationTitle("Missions")
            .background(.gray)
        }
    }
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
